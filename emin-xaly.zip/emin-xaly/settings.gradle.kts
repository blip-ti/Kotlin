rootProject.name = "ktor"

dependencyResolutionManagement {
    repositories {
        mavenCentral()
    }
}
